export class Eligibility {
    public name : string;
    public age : number;
    public gender : string;
    public mobileNo : string;
    public email : string;
    public emi : number;
    public vehicleType : string;
    public vehicleMake :string;
    public vehicleModel : string;
    public exShowroomPrice : number;
    public onRoadPrice : number;
    public employmentType : string;
    public annualIncome : number;
    public loantenure:number

}