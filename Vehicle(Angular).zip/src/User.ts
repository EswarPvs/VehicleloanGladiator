export class User
{
    fName:any;
    lName:any;
    mName:any;
    dob:String;
    mobile:any;
    amobile:any;
    email:any;
    uPassword:any;
    aMobile: any;
    pan: any;
    pincode: any;
    state: any;
    gender:any;
    city:any;



}