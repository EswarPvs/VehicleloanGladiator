export class UserLoginDto{
    public email : string;
    public password : string;
}

export class LoginStatus{
    public email : string;
    public status : string;
    public fName : string;
}
export class AdminLoginDto {
    public adminEmail : string;
    public adminPass : string;
}

export class AdminSignUp {
    public aId  : number;
    public aEmail : string;
    public status : string;
}