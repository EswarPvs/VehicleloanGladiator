export class ApplicationDto {
    public applicationId : number;
    public customerId : number;
    public aadhaar : string;
    public address : string;
    public accountNo : number;
    public accountType : string;
    public branch : string;
    public ifsc : string;
    public annualIncome : number;
    public existingEmi : number;
    public licence : string;
    public occupation : string;
    
}
export class Vehicle { //CarDetailDto
    public vehicleId : number;
    public companyName: string;
    public model: string;
    public variant: string;
    public category: string;
    public color: string;
    public exPrice: number;
}
export class Loan {  //LoanDetailDto
    public loanId : number;
    public vehicleId : number;
    public applicationId : number;
    public reqAmount: number;
    public tenure: number;
    public roi: number;
    public status: string;
}