import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { GetEligibilityComponent } from './get-eligibility/get-eligibility.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { VehicleService } from './vehicle.service';
import { EmiCalculatorComponent } from './emi-calculator/emi-calculator.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { LoanOfferComponent } from './loan-offer/loan-offer.component';
import { ApplicationComponent } from './application/application.component';
import { VehicleDetailsComponent } from './vehicle-details/vehicle-details.component';
import { LoanDetailsComponent } from './loan-details/loan-details.component';
import { LoanApplicationComponent } from './loan-application/loan-application.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ViewLoanComponent } from './view-loan/view-loan.component';
import { FormComponent } from './form/form.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    GetEligibilityComponent,
    RegisterComponent,
    EmiCalculatorComponent,
    LoginUserComponent,
    LoginAdminComponent,
    UserDashboardComponent,
    LoanOfferComponent,
    ApplicationComponent,
    VehicleDetailsComponent,
    LoanDetailsComponent,
    LoanApplicationComponent,
    AdminDashboardComponent,
    AboutUsComponent,
    ViewLoanComponent,
    FormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [VehicleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
