import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Loan } from 'src/details';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-loan-details',
  templateUrl: './loan-details.component.html',
  styleUrls: ['./loan-details.component.css']
})
export class LoanDetailsComponent implements OnInit {
  loan : Loan[];
  tempLoan : Loan[];
  private subscription : Subscription;
  constructor(private service:VehicleService) { }

  ngOnInit() {
    this.subscription = this.service.getAllLoans().subscribe((data:Loan[])=>{this.loan=data;
      this.tempLoan=data;
      console.log(this.loan)},
      (err)=>{console.log(err);
    })
  }
  
}

