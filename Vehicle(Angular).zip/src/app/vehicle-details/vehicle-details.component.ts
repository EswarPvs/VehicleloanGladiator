import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Vehicle } from 'src/details';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-vehicle-details',
  templateUrl: './vehicle-details.component.html',
  styleUrls: ['./vehicle-details.component.css']
})
export class VehicleDetailsComponent implements OnInit {
  vehicle : Vehicle[];
  tempVehicle : Vehicle[];
  private subscription : Subscription;
   
  constructor(private service:VehicleService,private router:Router) { }

  ngOnInit(){
  
      this.subscription = this.service.getAllCars().subscribe((data:Vehicle[])=>{this.vehicle=data;
        this.tempVehicle=data;
        console.log(this.vehicle)},
        (err)=>{console.log(err);
      })

       
 }
 onClick()
 {
  this.router.navigate(['loanapplication']);
 }
  
  }


