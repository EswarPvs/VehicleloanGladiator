import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emi-calculator',
  templateUrl: './emi-calculator.component.html',
  styleUrls: ['./emi-calculator.component.css']
})
export class EmiCalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  P:number;   
  R:number; //interest
  N:number; // months
  nu:number;
  den:number;
  val:number; 
  condition:Boolean;
  updateEmi() {  
    var monthlyInterestRatio = (this.R / 100) / 12;
     var nume = Math.pow((1 + monthlyInterestRatio), this.N);
     var den = nume - 1;
     var sp = nume / den;
     this.val = Math.round((this.P * monthlyInterestRatio) * sp);
     this.condition=true;
}

}
