import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminLoginDto, AdminSignUp } from 'src/login';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-login-admin',
  templateUrl: './login-admin.component.html',
  styleUrls: ['./login-admin.component.css']
})
export class LoginAdminComponent implements OnInit {
  login: AdminLoginDto = new AdminLoginDto;
  user: AdminSignUp = new AdminSignUp;

  constructor(private service:VehicleService,private router:Router) { }

  ngOnInit(): void {
  }
  adminLoginCheck(){
    this.service.adminLoginCheck(this.login).subscribe(data=>{this.user=data;
      console.log(this.user.status)
      if(this.user.status=="failure")
      {
        alert("Wrong credentials, try again.");
      }
      else{
        sessionStorage.setItem("adminemail",this.user.aEmail);
        this.router.navigate(['adminboard']);
        
      }
    })
  }
  }

