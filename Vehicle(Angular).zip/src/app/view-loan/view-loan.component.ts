import { Component, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Loan } from 'src/details';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-view-loan',
  templateUrl: './view-loan.component.html',
  styleUrls: ['./view-loan.component.css']
})
export class ViewLoanComponent implements OnInit {

  constructor(private service:VehicleService) { }
  loanId:string;
  loan:Loan;
  tempLoan:Loan;
  private subscription: Subscription;


  ngOnInit(){
    
}
onClick()
{
  console.log(this.loanId);
    alert(this.loanId);
    this.subscription = this.service.viewLoan(this.loanId).subscribe((data:Loan)=>{this.loan=data;
      this.tempLoan=data;
      alert(this.tempLoan);
      console.log(this.loan)},
      (err)=>{console.log(err);
    })
  }
}