import { Component, OnInit } from '@angular/core';
import { LoginStatus } from 'src/login';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  user: LoginStatus = new LoginStatus;
  uname: string;

  constructor() { }

  ngOnInit(){
    this.uname= sessionStorage.getItem("userName");
     
  }

}
