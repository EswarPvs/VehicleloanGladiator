import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ApplicationComponent } from './application/application.component';
import { EmiCalculatorComponent } from './emi-calculator/emi-calculator.component';
import { FormComponent } from './form/form.component';
import { GetEligibilityComponent } from './get-eligibility/get-eligibility.component';
import { LoanApplicationComponent } from './loan-application/loan-application.component';
import { LoanDetailsComponent } from './loan-details/loan-details.component';
import { LoanOfferComponent } from './loan-offer/loan-offer.component';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { RegisterComponent } from './register/register.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { VehicleDetailsComponent } from './vehicle-details/vehicle-details.component';

const routes: Routes = [
  {path:"register",component:RegisterComponent}
  ,{path:"Emi",component:EmiCalculatorComponent},
  {path:"UserLogin",component:LoginUserComponent},
  {path:"adminLogin",component:LoginAdminComponent},
  {path:"userDashboard",component:UserDashboardComponent,
     children:[
             {path:"eligibility",component:GetEligibilityComponent},
],
  },
  {path:"loanoffers",component:LoanOfferComponent},
  {path:"application",component:ApplicationComponent},
  {path:"aboutus",component:AboutUsComponent},
  {path:"vehicle",component:VehicleDetailsComponent},
  {path:"loanapplication",component:LoanApplicationComponent},
  {path:"loandetails",component:LoanDetailsComponent},
  {path:"form",component:FormComponent},
  {path:"adminboard",component:AdminDashboardComponent,
  children:[
    {path:"loandetails",component:LoanDetailsComponent},
],
}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
