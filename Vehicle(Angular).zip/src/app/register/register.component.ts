import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/User';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user:User;

  constructor(private service:VehicleService,private router:Router) { 
   this.user=new User();
  }
 
    

  ngOnInit(): void {
  }
  onRegisterClick()
  {
    this.service.register(this.user)
    .subscribe(data=>
      {
        alert("your user id is "+data);
        

      });
      this.router.navigate(['UserLogin']);

    
  }

}
