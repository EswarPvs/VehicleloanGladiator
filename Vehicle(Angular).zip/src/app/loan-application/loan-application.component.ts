import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Loan } from 'src/details';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-loan-application',
  templateUrl: './loan-application.component.html',
  styleUrls: ['./loan-application.component.css']
})
export class LoanApplicationComponent implements OnInit {
  loan : Loan = new Loan;
  constructor(private service:VehicleService,private router:Router) { }

  ngOnInit(): void {
  }
  save() {
    this.service.saveLoan(this.loan).subscribe(data=>
      {
        alert(data);
        

      });
     this.router.navigate(['form']);

}
}
