import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationDto } from 'src/details';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit {
  app : ApplicationDto  = new ApplicationDto;

  constructor(private service:VehicleService,private router:Router) { }

  ngOnInit(): void {
  }
     save()
     {
       this.service.saveApp(this.app).subscribe(data=>
        {
          alert("your application id is "+data);
        });
        this.router.navigate(['vehicle']);

     }
}

  