import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { User } from 'src/User';
import { Observable } from 'rxjs';
import { AdminLoginDto, AdminSignUp, LoginStatus, UserLoginDto } from 'src/login';
import { ApplicationDto, Loan, Vehicle } from 'src/details';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {
  private baseUrl : string = "http://localhost:8090";
  saveUser: any;
  constructor(private http:HttpClient) { }

  register(user:User)
  {
    return this.http.post("http://localhost:8090/addRegister",user)
  }
  
  userLoginCheck(login : UserLoginDto) : Observable<LoginStatus>{
    const Url ="http://localhost:8090/userLogin";
    return this.http.post<LoginStatus>(Url,login);
}
saveApp(app1 : ApplicationDto ) {
  return this.http.post(this.baseUrl+"/newApplication", app1);
}
getAllCars() : Observable<Vehicle[]>{
  return this.http.get<Vehicle[]>(this.baseUrl+"/allCars");
}
saveLoan(app3 : Loan) {
  return this.http.post(this.baseUrl+"/newLoan",app3);
}
adminLoginCheck(login : AdminLoginDto) : Observable<AdminSignUp>{
  const Url ="http://localhost:8090/adminLogin";
  return this.http.post<AdminSignUp>(Url,login);
}
getAllLoans() : Observable<Loan[]>{
  return this.http.get<Loan[]>(this.baseUrl+"/getloandetail");
}
viewLoan(loanId:string):Observable<Loan>
{
  alert("inservice"+loanId);
  return this.http.post<Loan>(this.baseUrl+"/getLoanById/"+loanId,loanId);
}
// getApplicationStatus(statusDto :StatusDto): Observable<StatusDto[]>{
//   console.log("inside service")
//  return this.http.post<StatusDto[]>(this.url+"getappdetails", statusDto);
//   // console.log("OUTOF  service");
// }

}
