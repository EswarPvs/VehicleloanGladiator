import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Eligibility } from 'src/Eligibility';

@Component({
  selector: 'app-get-eligibility',
  templateUrl: './get-eligibility.component.html',
  styleUrls: ['./get-eligibility.component.css']
})
export class GetEligibilityComponent implements OnInit {
  eligible = new Eligibility;

  constructor(private router:Router) { }
  annualincome:number;
  emi:number;
  age:number;
  
  ngOnInit(): void {
  }
  checkEligibility() {
    if (this.annualincome<300000) {
      alert("Sorry you are not eligible for Loan");
     // this.router.navigate(['home']);
    }
    else if (this.emi > ((this.annualincome/12)*0.5)) {
      alert("Sorry you are not eligible for Loan. Your existing EMI is not compliance with our terms and conditions.");
    //  this.router.navigate(['home']);
    }
    else {
      if(this.annualincome>300000)
      var ans = confirm("Congratulations you are eligible for a loan of ₹ " + this.annualincome*2.5 + ". Do you want to check our loan offers now!");
      
      if (ans) 
      {
        this.router.navigate(['loanoffers']);
      } 
    }
  }

}
