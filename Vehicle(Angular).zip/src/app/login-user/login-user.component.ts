import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginStatus, UserLoginDto } from 'src/login';
import { VehicleService } from '../vehicle.service';


@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {
  login: UserLoginDto = new UserLoginDto;
  user: LoginStatus = new LoginStatus;

  constructor(private service:VehicleService, private router: Router) { }

  ngOnInit(): void {
  }
  loginCheck(){
    this.service.userLoginCheck(this.login).subscribe(data=>{this.user=data;
      console.log(this.user.status)
      if(this.user.status=="failure")
      {
        alert("Wrong credentials, try again.");
      }
      else{
        sessionStorage.setItem("userName",this.user.fName);
        this.router.navigate(['userDashboard']);
        
      }
    })
  }
}


