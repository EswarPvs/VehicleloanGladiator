package com.lti;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.lti.entity.Admin;
import com.lti.entity.Application;
import com.lti.entity.CarDetail;
import com.lti.entity.EmiSchedule;
//import com.lti.entity.Cardetail;
import com.lti.entity.LoanDetail;
//import com.lti.entity.Loandetail;
import com.lti.entity.Register;
import com.lti.repo.AdminRepo;
import com.lti.repo.ApplicationRepo;
import com.lti.repo.CarDetailRepo;
import com.lti.repo.EmiSchedRepo;
import com.lti.repo.LoanDetailRepo;
//import com.lti.repo.ApplicationRepoImpl;
import com.lti.repo.RegisterRepo;
//import com.lti.repo.RegisterRepoImpl;

@SpringBootTest
class ProjectGladiatorVehicleLoanProjectApplicationTests {

	@Autowired
	RegisterRepo obj;
	
	@Autowired
	AdminRepo adr;
	
	@Autowired
	ApplicationRepo app;
	@Autowired
	CarDetailRepo cdr;
	@Autowired
	LoanDetailRepo ldr;
	@Autowired
	EmiSchedRepo esr;
	
	@Test
	void contextLoads() {
	List<Register> registerlist = new ArrayList<Register>();
	registerlist = obj.getAllRegisterers();
	System.out.println("All the Registerers");
	for (Register register : registerlist) {
		System.out.println("Register : "+register);
	}
	
	}
	
	@Test
	void contextLoads1() {
		Register ref = obj.getOneRegisterer(101);
	 
		  System.out.println("getOneRegisterer() is called");
	     System.out.println(ref.getEmail());
		 System.out.println(ref.getPassword());
		 System.out.println(ref.getFirstName());
		 System.out.println(ref.getMobile());
		 System.out.println(ref.getMiddleName());
		 System.out.println(ref.getLastName());
		 System.out.println(ref.getCity());
		 System.out.println(ref.getState());
		 System.out.println(ref.getPincode());
		 System.out.println(ref.getDob());
		 System.out.println(ref.getPan());
		 System.out.println(ref.getAlterMobile());
	}
	
	@Test
	void contextLoads2() {
		Register newRegister = new Register();
		
		newRegister.setEmail("rahul@gmail.com");
		newRegister.setPassword("1254");
		newRegister.setFirstName("rahul");
		newRegister.setMiddleName("krishna");
		newRegister.setLastName("ramachandran");
		newRegister.setGender("m");
		newRegister.setDob(LocalDate.of(1995, 5, 24));
		newRegister.setState("MH");
		newRegister.setPincode(421635);
		newRegister.setCity("Nagpur");
		newRegister.setMobile("9755745793");
		newRegister.setAlterMobile("8746305435");
		newRegister.setPan("RUB7831Q");
		obj.addRegisterer(newRegister);
		System.out.println("Registerer Added...");
	
		
	}
	
	@Test
	void contextload3() {
		try {
			obj.updateRegistererPassword(103, "121212");    
			System.out.println("Password updated Successfully...");
		} catch (Exception e) {
			System.out.println("Message: Registerer doesn't exist ");
		}
	}
	
	@Test
	void contextload4() {
		List<Admin> adminlist = new ArrayList<Admin>();
		adminlist = adr.getAllAdmins();     
		System.out.println("All the Admins");
		for (Admin admin : adminlist) {
			System.out.println("Admin : "+admin);
		}
	}
	

	@Test
	void contextLoads5() {
		Admin ad = adr.getOneAdmin(501);
		
		System.out.println("getOneAdmin() is called");
	     
		 System.out.println(ad.getAdminEmail());
		 System.out.println(ad.getAdminPass());
	}
	
	
	@Test
	void contextLoads6() {
		Admin ad = new Admin();
		
		ad.setAdminEmail("admin3@gmail.com");
		ad.setAdminPass("admin");
		adr.addAdmin(ad);
		System.out.println("Admin added successfully.....");
	}
	
	
	
	@Test
	void contextload7() {
		try {
			adr.updateAdminPassword(62, "admin3");    
			System.out.println("Password updated Successfully...");
		} catch (Exception e) {
			System.out.println("Message: Admin doesn't exist ");
		}
	}
	
	@Test
	void contextLoads8() {
		adr.deleteAdmin(502);
		System.out.println("Admin removed Successfully.....");
	}
	
	
	@Test
	void contextLoads9() {
	List<Application> applicationList = new ArrayList<Application>();
	applicationList = app.getAllApplications();
	System.out.println("All the Applicants");
	for (Application application : applicationList) {
		System.out.println("Applicant : "+application);
	}
	
	}
	
	@Test
	void contextLoads10() {
		Application appli = app.getOneApplication(184);
	 
		  System.out.println("getOneApplication() is called");
	     System.out.println(appli.getAadhaar());
		 System.out.println(appli.getAccountNo());
		 System.out.println(appli.getAccountType());
		 System.out.println(appli.getAddress());
		 System.out.println(appli.getAnnualIncome());
		 System.out.println(appli.getBranch());
		 System.out.println(appli.getExistingEmi());
		 System.out.println(appli.getIfsc());
		 System.out.println(appli.getLicence());
		 System.out.println(appli.getOccupation());
		  System.out.println(appli.getLoanDetail());
		  System.out.println(appli.getRegister());
		  //System.out.println(appli.getVehicle());
		 
	}
	
	@Test
	void contextLoads11() {
		Register ref = obj.getOneRegisterer(101);
		
		Application newApp = new Application();
		
		newApp.setAadhaar("218782168842");
		newApp.setAccountNo(41526);
		newApp.setAccountType("Savings");
		newApp.setAddress("545_MG-road");
		newApp.setAnnualIncome(1100000);
		newApp.setBranch("gurudwar");
		newApp.setExistingEmi(0);
		newApp.setIfsc("AX46662");
		newApp.setLicence("AP5462682198");
		newApp.setOccupation("consultant");
		
		newApp.setRegister(ref);
		System.out.println("Add Application() is called...");
		
		System.out.println("Application Added: "+newApp);
		app.addApplication(newApp);
	}
	
	
	@Test
	void contextLoads12() {
	List<LoanDetail> loanDetailsList = new ArrayList<LoanDetail>();
	loanDetailsList = ldr.getAllLoanDetails();
	System.out.println("getAllLoanDetails() is loaded...");
		for (LoanDetail ldl : loanDetailsList) {
			System.out.println("LoanDetail : "+ldl);
		}
	
	}
	
	@Test
	void contextLoads13() {
		LoanDetail ldl = ldr.getOneLoan(1001);
	 
		  System.out.println("getOneLoandetail() is called");
	     System.out.println(ldl.getReqAmount());
		 System.out.println(ldl.getRoi());
		 System.out.println(ldl.getTenure());
		 System.out.println(ldl.getStatus());
		  System.out.println(ldl.getApplication());
		  //System.out.println(ldl.getCardetail());
		 // System.out.println(ldl.getEmisched());
		 
	}
	
	@Test
	void contextLoads14() {
		Application ref = app.getOneApplication(126); //  77        102 D1_SaiApts_34Strt    MH2738626878 	369854214514         78965                Nagpur     AX628805   Current 		Software_Engineer    1200000              0
		CarDetail car = cdr.getOneCar(125); // 84 Hyundai    i10        basic      blue       petrol     600000
		
		/*select * from loandetails;

	    LOANID      VEHID      APPID AMTREQ     TENURE     ROI        STATUS
	---------- ---------- ---------- ---------- ---------- ---------- ----------
	      1001          1        201 700000     84 months  8.0%       approved
	      1002          2        202 1500000    84 months  7.5%       approved
	      1003          3        203 900000     84 months  8.0%       approved
	      1111          3        77    entered by us
	      1004          84       77
	      Auto			car      ref    entered by us
	      
	      */
		
		//Set<Loandetail> loanSet = new HashSet<Loandetail>();
		LoanDetail ldl = new LoanDetail();
		ldl.setReqAmount(465000);
		ldl.setRoi(8.2);
		ldl.setTenure(84);
		ldl.setStatus("Pending");
		ldl.setCarDetail(car);
		ldl.setApplication(ref);
		
		ref.setLoanDetail(ldl);
		//loanSet.add(ldl);
		
		
		//car.setLoandetails(loanSet);
		//cdr.addCar(car);
		//ref.setLoandetail(ldl);
		
		
		System.out.println("AddLoanDetail() is called....");
		
		System.out.println("Loan Details added: "+ldl);
		//app.addApplication(ref);
		ldr.addLoan(ldl);
		
	}
	
	
	@Test
    void contextLoads15() {
        CarDetail car=cdr.getOneCar(125);
        System.out.println(car.getColor());
        System.out.println(car.getCompanyName());
        System.out.println(car.getModel());
        System.out.println(car.getVariant());
  
    }
	
	
    @Test
    void contextLoads16()
    {
        CarDetail car=new CarDetail();
        car.setCategory("standard");
        car.setColor("blue");
        car.setCompanyName("Hyundai");
        car.setExPrice(680000);
        car.setModel("celerio");
        car.setVariant("petrol");
        
        cdr.addCar(car);
                
    }
    @Test
    void contextLoads17()
    {
        List<CarDetail> carList = new ArrayList<CarDetail>();
        carList = cdr.getAllCars();
        System.out.println("All the  Cars");
        for (CarDetail cardetail : carList) 
        {
            
            System.out.println("CarDetail :"+cardetail);
    
        }
    }
    
    
    @Test
	void contextload18() {
		try {
			cdr.updateCar(2, 1695000);    
			System.out.println("ExShowRoom Price updated Successfully...");
		} catch (Exception e) {
			System.out.println("Message: vehId doesn't exist ");
		}
	}
    
    
    @Test
    void contextLoads19()
    {
        List<EmiSchedule> emiList = new ArrayList<EmiSchedule>();
        emiList = esr.getAllEmiSchedules();
        System.out.println("All the  EmiSchedules");
        for (EmiSchedule emiSchedule : emiList) 
        {
            
            System.out.println("EmiSchedule :"+emiSchedule);
    
        }
    }
    
    
    @Test
    void contextLoads20() {
    	EmiSchedule emi=esr.getOneEmiSched(1001);
        System.out.println(emi.getSanctionedDate());
        System.out.println(emi.getAppliedDate());
        System.out.println(emi.getEmi());
        System.out.println(emi.getEmiScheduler());
        System.out.println(emi.getTotalLoan());
  
    }
    
    
    @Test
	void contextload21() {
		try {
			esr.updateLoanSanctioned(1003, 885000);    
			System.out.println("Loan Amount Sanctioned updated Successfully...");
		} catch (Exception e) {
			System.out.println("Message: loanId doesn't exist ");
		}
	}
    
    @Test
	void contextload22() {
		try {
			esr.updateEmiScheduler(1003, 3);    
			System.out.println("Emi Scheduler date updated Successfully...");
		} catch (Exception e) {
			System.out.println("Message: loanId doesn't exist ");
		}
	}
    @Test
    void contextload23() {
    	List<Object[]> allapplicants=app.getApplicantdetails();
    	for(Object[] applicantsList:allapplicants)
    	{
    		System.out.println(Arrays.toString(applicantsList));
    	}
    }
    
}
