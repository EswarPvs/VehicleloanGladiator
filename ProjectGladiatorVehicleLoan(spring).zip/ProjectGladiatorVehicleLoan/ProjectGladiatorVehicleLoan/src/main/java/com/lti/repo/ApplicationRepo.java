package com.lti.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.dto.ApplicationDto;
import com.lti.entity.Application;
import com.lti.entity.Register;

@Repository
public interface ApplicationRepo {
	//application
	public Application getOneApplication(int appId);
	public List<Application> getAllApplications();
	public void addApplication(Application ref);
    public List<Object[]>getApplicantdetails();
    public int addApplication(ApplicationDto applicationDto);
	
}
