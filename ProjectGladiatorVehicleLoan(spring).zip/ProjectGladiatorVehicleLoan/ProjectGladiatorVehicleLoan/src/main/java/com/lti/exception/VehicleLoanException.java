package com.lti.exception;

public class VehicleLoanException extends RuntimeException{
	
	public VehicleLoanException() {
		super();
	}
	public VehicleLoanException(String msg) {
		super(msg);
	}
}