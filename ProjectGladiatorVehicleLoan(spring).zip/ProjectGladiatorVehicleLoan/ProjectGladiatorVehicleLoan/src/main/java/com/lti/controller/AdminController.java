package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.AdminLoginDto;
import com.lti.dto.AdminSignUP;
import com.lti.dto.LoanDetailDto;
import com.lti.dto.LoanStatus;
import com.lti.entity.LoanDetail;
import com.lti.service.LoanDetailService;
import com.lti.service.LoginService;




	
	@RestController
	@CrossOrigin(origins = "http://localhost:4200")
	public class AdminController {
		@Autowired
		LoanDetailService lds;
		@Autowired
		LoginService lsr;
		
		@GetMapping(path = "/getloandetail")
		public List<LoanDetailDto> getAllLoans()
		{
			return this.lds.getLoanDetails();
		}
		@PutMapping(path = "/updatestatus") 
		public LoanDetail updateStatus(@RequestBody LoanStatus loanStatus)
		{
			return this.lds.updateStatus(loanStatus);
		}
		@PostMapping(path="/adminLogin")
		public AdminSignUP adminLogin(@RequestBody AdminLoginDto alDto) {
			
				return lsr.adminLogin(alDto);
			
		}
		

	}



