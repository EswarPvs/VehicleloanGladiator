package com.lti.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.entity.CarDetail;
//import com.lti.entity.Cardetail;


@Repository
public interface CarDetailRepo {
		
	public List<CarDetail> getAllCars();
	public CarDetail getOneCar(int vehId);
	public void addCar(CarDetail car);
	public void updateCar(int vehId, int newExPrice);
	//public void deleteCar(int vehId);
	
	
	
}
