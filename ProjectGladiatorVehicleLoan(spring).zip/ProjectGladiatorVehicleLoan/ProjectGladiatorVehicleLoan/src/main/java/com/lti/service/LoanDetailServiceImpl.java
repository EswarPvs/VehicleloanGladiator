package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dto.LoanDetailDto;
import com.lti.dto.LoanStatus;
import com.lti.entity.LoanDetail;
import com.lti.repo.LoanDetailRepo;

@Service
public class LoanDetailServiceImpl implements LoanDetailService {
	
	@Autowired
	LoanDetailRepo ld;


	@Override
	public List<LoanDetailDto> getLoanDetails() {
		// TODO Auto-generated method stub
		return ld.getLoanDetails();
	}


	@Override
	public LoanDetail updateStatus(LoanStatus loanstatus) {
		// TODO Auto-generated method stub
		return ld.updateStatus(loanstatus);
	}


	@Override
	public LoanDetailDto getLoanById(int loanId) {
	
		return ld.getLoanById(loanId);
	}


	@Override
	public int addnewLoan(LoanDetailDto loanDetailDto) {
		return ld.addnewLoan(loanDetailDto);
	}
	

}
