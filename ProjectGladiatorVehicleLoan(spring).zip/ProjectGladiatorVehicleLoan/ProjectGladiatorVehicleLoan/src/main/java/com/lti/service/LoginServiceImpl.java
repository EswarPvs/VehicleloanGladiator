package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dto.AdminLoginDto;
import com.lti.dto.AdminSignUP;
import com.lti.dto.LoginStatus;
import com.lti.dto.UserLoginDto;
import com.lti.entity.Admin;
import com.lti.entity.Register;
import com.lti.exception.VehicleLoanException;
import com.lti.repo.AdminRepo;
import com.lti.repo.RegisterRepo;
@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	RegisterRepo regRepo;
	@Autowired
	AdminRepo admRepo;

	@Override
	public LoginStatus userLogin(UserLoginDto ulDto) throws VehicleLoanException {
		LoginStatus result = new LoginStatus();
		try {
			String email = ulDto.getEmail();
			String password = ulDto.getPassword();
			
		
		Register reg;
		reg = regRepo.getOneUserwithEmail(email);
		
			if(password.equalsIgnoreCase(reg.getPassword())) {
				System.out.println("Password matched");
				result.setEmail(reg.getEmail());
				result.setStatus("success");
				result.setfName(reg.getFirstName());
				return result;
			}
			else {
				result.setEmail(null);
				result.setStatus("failed");
				result.setfName(null);
				return result;
			}
		} catch (VehicleLoanException e) {
			result.setEmail(null);
			result.setStatus("failed");
			result.setfName(null);
			return result;
		}
		
	}

	@Override
	public AdminSignUP adminLogin(AdminLoginDto alDto) throws VehicleLoanException {
		AdminSignUP result = new AdminSignUP();
		
		try {
			String adminEmail = alDto.getAdminEmail();
			String adminPass = alDto.getAdminPass();
			
			Admin adm;
				adm = admRepo.getOneAdminByEmail(adminEmail);
			
			if(adminPass.equalsIgnoreCase(adm.getAdminPass())) {
				System.out.println("Password matched");
				result.setaEmail(adm.getAdminEmail());
				result.setaId(adm.getAdminId());
				result.setStatus("success");
				
				return result;
			}
			else {
				result.setaEmail(null);
				result.setaId(0);
				result.setStatus("failed");
				return result;
				
			}
		} catch (VehicleLoanException e) {
			result.setaEmail(null);
			result.setaId(0);
			result.setStatus("failed");
			return result;
		}
		
	}

}
