package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.ApplicationDto;
import com.lti.dto.LoanDetailDto;
import com.lti.dto.LoginStatus;
import com.lti.dto.RegisterDto;
import com.lti.dto.UserLoginDto;
import com.lti.entity.Application;
import com.lti.repo.LoanDetailRepo;
import com.lti.service.ApplicationService;
import com.lti.service.CarDetailService;
import com.lti.service.LoanDetailService;
import com.lti.service.LoginService;
import com.lti.service.RegisterServiceRepo;
import com.lti.entity.CarDetail;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class RegisterController {
	@Autowired
	RegisterServiceRepo rs;
	@Autowired
	LoanDetailRepo ls;
	@Autowired
	ApplicationService as;
	@Autowired
	LoginService lsr;
	@Autowired
	LoanDetailService ldService;
	@Autowired
	CarDetailService cdService;
	
	@PostMapping(path = "/addRegister") //done
	public int addNewUser(@RequestBody RegisterDto registerDto)
	{
		return this.rs.addUser(registerDto);
	}
	
	@GetMapping(path = "/getUserById/{uId}") //done
	public RegisterDto getUserById(@PathVariable String uId)
	{
		RegisterDto register = this.rs.getUserById(Integer.parseInt(uId));
		return register;
	}
	
	
	@PostMapping(path = "/getLoanById/{lId}") //done
	public LoanDetailDto getLoanById( @PathVariable String lId) {
		// TODO Auto-generated method stub
		return ls.getLoanById(Integer.parseInt(lId));
	}
		
		@PostMapping(path="/addApplication")
		//@ResponseBody
		public String addApplicationDetail(@RequestBody Application application) {
			
			try {
				as.addApplicationDetail(application);
				return "Application added Successfully";
			} catch (Exception e) {
				// TODO Auto-generated catch block
				return e.getMessage();
			}
		}
		
		@PostMapping(path="/newApplication")
		public int addApplication(@RequestBody ApplicationDto applicationDto)
		{
			return this.as.addApplication(applicationDto);
		}
		
		@PostMapping(path="/userLogin")
		public LoginStatus userLogin(@RequestBody UserLoginDto ulDto) {
			
				return lsr.userLogin(ulDto);
				
			 
		}
		@PostMapping(path="/newLoan")
		public int addNewLoan(@RequestBody LoanDetailDto loandetailDto)
		{
			return this.ldService.addnewLoan(loandetailDto);
		}
		@GetMapping(path = "/allCars")//To be changed
		public List<CarDetail> getAllCars()
		{
			return cdService.getAllCars();
		}
		
		

}

