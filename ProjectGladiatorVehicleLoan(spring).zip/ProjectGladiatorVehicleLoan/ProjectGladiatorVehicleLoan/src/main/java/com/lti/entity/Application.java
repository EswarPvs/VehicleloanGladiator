package com.lti.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;


/**
 * The persistent class for the APPLICATION database table.
 * 
 */
@Entity
@NamedQuery(name="Application.findAll", query="SELECT a FROM Application a")
public class Application implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="APPLICATION_ID")
	private int applicationId;

	private String aadhaar;

	@Column(name="ACCOUNT_NO")
	private int accountNo;

	@Column(name="ACCOUNT_TYPE")
	private String accountType;

	private String address;

	@Column(name="ANNUAL_INCOME")
	private int annualIncome;

	private String branch;

	@Column(name="EXISTING_EMI")
	private int existingEmi;

	private String ifsc;

	private String licence;

	private String occupation;

	//bi-directional many-to-one association to Register
	@ManyToOne
	@JoinColumn(name="CUSTOMER_ID")
	private Register register;

	//bi-directional one-to-one association to Identity
	@OneToOne(mappedBy="application")
	private Identity identity;
	/*
	//bi-directional many-to-one association to LoanDetail
	@OneToMany(mappedBy="application1", fetch=FetchType.EAGER)
	private Set<LoanDetail> loanDetails;
	*/
	//bi-directional one-to-one association to LoanDetail
	@OneToOne(mappedBy ="application")
	//@JoinColumn(name="APPLICATION_ID", referencedColumnName="APPLICATION_ID")
	private LoanDetail loanDetail;

	public Application() {
	}

	public int getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getAadhaar() {
		return this.aadhaar;
	}

	public void setAadhaar(String aadhaar) {
		this.aadhaar = aadhaar;
	}

	public int getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return this.accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAnnualIncome() {
		return this.annualIncome;
	}

	public void setAnnualIncome(int annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getBranch() {
		return this.branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public int getExistingEmi() {
		return this.existingEmi;
	}

	public void setExistingEmi(int existingEmi) {
		this.existingEmi = existingEmi;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getLicence() {
		return this.licence;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public String getOccupation() {
		return this.occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	
	@JsonIgnore
	public Register getRegister() {
		return this.register;
	}

	public void setRegister(Register register) {
		this.register = register;
	}
	@JsonIgnore
	public Identity getIdentity() {
		return this.identity;
	}

	public void setIdentity(Identity identity) {
		this.identity = identity;
	}
	/*
	public Set<LoanDetail> getLoanDetails() {
		return this.loanDetails;
	}

	public void setLoanDetails(Set<LoanDetail> loanDetails) {
		this.loanDetails = loanDetails;
	}

	public LoanDetail addLoanDetail(LoanDetail loanDetail) {
		getLoanDetails().add(loanDetail);
		loanDetail.setApplication1(this);

		return loanDetail;
	}

	public LoanDetail removeLoanDetail(LoanDetail loanDetail) {
		getLoanDetails().remove(loanDetail);
		loanDetail.setApplication1(null);

		return loanDetail;
	}
	*/
	@JsonIgnore
	public LoanDetail getLoanDetail() {
		return this.loanDetail;
	}

	public void setLoanDetail(LoanDetail loanDetail) {
		this.loanDetail = loanDetail;
	}

}