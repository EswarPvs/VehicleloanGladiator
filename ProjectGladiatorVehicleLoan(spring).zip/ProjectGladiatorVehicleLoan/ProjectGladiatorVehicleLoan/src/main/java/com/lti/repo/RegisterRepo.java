package com.lti.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.dto.RegisterDto;
import com.lti.entity.Register;

@Repository
public interface RegisterRepo {
	
	
	//register
	public Register getOneRegisterer(int custId);
	public List<Register> getAllRegisterers();
	public void addRegisterer(Register ref);
	public void updateRegistererPassword(int custId, String newPassword);
	public int addRegister(RegisterDto registerDto);
	public RegisterDto getUserById(int custid);
	public Register getOneUserwithEmail(String email);
	
}
