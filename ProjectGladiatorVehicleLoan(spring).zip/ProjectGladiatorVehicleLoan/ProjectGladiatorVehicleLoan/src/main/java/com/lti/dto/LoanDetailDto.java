package com.lti.dto;

public class LoanDetailDto {
	private int loanId;
	private int vehicleId;
	private int applicationId;
	private int reqAmount;
	private double roi;
	private int tenure;
	private String status;
	
	public LoanDetailDto() {
	
	}
	
	public LoanDetailDto(int loanId, int vehicleId, int applicationId, int reqAmount, double roi, int tenure,
			String status) {
		super();
		this.loanId = loanId;
		this.vehicleId = vehicleId;
		this.applicationId = applicationId;
		this.reqAmount = reqAmount;
		this.roi = roi;
		this.tenure = tenure;
		this.status = status;
	}

	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
	public int getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public int getReqAmount() {
		return reqAmount;
	}
	public void setReqAmount(int reqAmount) {
		this.reqAmount = reqAmount;
	}
	public double getRoi() {
		return roi;
	}
	public void setRoi(double roi) {
		this.roi = roi;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
