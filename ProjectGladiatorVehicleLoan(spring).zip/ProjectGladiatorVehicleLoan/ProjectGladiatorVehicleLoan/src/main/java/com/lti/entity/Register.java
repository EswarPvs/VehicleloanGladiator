package com.lti.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the "REGISTER" database table.
 * 
 */
@Entity
@Table(name="REGISTER")
@NamedQuery(name="Register.findAll", query="SELECT r FROM Register r")
public class Register implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CUSTOMER_ID")
	private int customerId;

	@Column(name="ALTER_MOBILE")
	private String alterMobile;

	private String city;

	//@Temporal(TemporalType.DATE)
	@Column(columnDefinition = "DATE")
	private LocalDate dob;

	private String email;

	@Column(name="FIRST_NAME")
	private String firstName;

	private String gender;

	@Column(name="LAST_NAME")
	private String lastName;

	@Column(name="MIDDLE_NAME")
	private String middleName;

	private String mobile;

	private String pan;

	private String password;

	private int pincode;

	@Column(name="STATE")
	private String state;

	//bi-directional many-to-one association to Application
	@OneToMany(mappedBy="register", fetch=FetchType.EAGER)
	private Set<Application> applications;

	public Register() {
	}

	public int getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAlterMobile() {
		return this.alterMobile;
	}

	public void setAlterMobile(String alterMobile) {
		this.alterMobile = alterMobile;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public LocalDate getDob() {
		return this.dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPan() {
		return this.pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getPincode() {
		return this.pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Set<Application> getApplications() {
		return this.applications;
	}

	public void setApplications(Set<Application> applications) {
		this.applications = applications;
	}

	public Application addApplication(Application application) {
		getApplications().add(application);
		application.setRegister(this);

		return application;
	}

	public Application removeApplication(Application application) {
		getApplications().remove(application);
		application.setRegister(null);

		return application;
	}

}