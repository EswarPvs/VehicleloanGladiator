package com.lti.dto;

public class CarDetailDto {
	private String companyName;
	private String model;
	private String variant;
	private String category;
	private String color;
	private int exPrice;
	
	
	public CarDetailDto() {
		
	}
	public CarDetailDto(String companyName, String model, String variant, String category, String color, int exPrice) {
		super();
		this.companyName = companyName;
		this.model = model;
		this.variant = variant;
		this.category = category;
		this.color = color;
		this.exPrice = exPrice;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getVariant() {
		return variant;
	}
	public void setVariant(String variant) {
		this.variant = variant;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getExPrice() {
		return exPrice;
	}
	public void setExPrice(int exPrice) {
		this.exPrice = exPrice;
	}
	
	
}



