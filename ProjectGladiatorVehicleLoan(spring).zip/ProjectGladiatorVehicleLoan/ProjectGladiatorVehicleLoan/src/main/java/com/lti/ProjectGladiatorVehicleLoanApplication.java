package com.lti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectGladiatorVehicleLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectGladiatorVehicleLoanApplication.class, args);
		System.out.println("Welcome to Vehicle Loan website");
	}

}
