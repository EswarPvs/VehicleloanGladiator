package com.lti.dto;

public class AdminLoginDto {
	private String adminEmail;
	private String adminPass;
	
	
	public AdminLoginDto() {
		
	}
	public AdminLoginDto(String adminEmail, String adminPass) {
		super();
		this.adminEmail = adminEmail;
		this.adminPass = adminPass;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getAdminPass() {
		return adminPass;
	}
	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}
	
	

}



