package com.lti.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.entity.EmiSchedule;
//import com.lti.entity.Emisched;
@Repository
public interface EmiSchedRepo {
		
		public List<EmiSchedule> getAllEmiSchedules();
		public EmiSchedule getOneEmiSched(int loanId);
		public void updateLoanSanctioned (int loanId,int newAmount);
		public void updateEmiScheduler (int loanId,int newSchedule);
		
		
		
}
