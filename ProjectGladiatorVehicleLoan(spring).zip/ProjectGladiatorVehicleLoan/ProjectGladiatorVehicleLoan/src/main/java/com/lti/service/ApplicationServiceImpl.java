package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dto.ApplicationDto;
import com.lti.entity.Application;
import com.lti.repo.ApplicationRepo;
@Service
public class ApplicationServiceImpl implements ApplicationService {
	
	@Autowired
	ApplicationRepo appl;
	
	@Override
	public void addApplicationDetail(Application ref) {
		appl.addApplication(ref);
	}

	@Override
	public int addApplication(ApplicationDto applicationDto) {
		try {// TODO Auto-generated method stub
			return appl.addApplication(applicationDto);
			}catch(Exception e) {
				throw new RuntimeException("Problem creating Application");
			}
}
}
		
		

