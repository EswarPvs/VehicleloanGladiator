package com.lti.dto;

public class UpdateRegister {
	private int customerId;
	private String mobile;
	private String password;
	
	
	public UpdateRegister() {

	}
	
	
	public UpdateRegister(int customerId, String mobile, String password) {
		super();
		this.customerId = customerId;
		this.mobile = mobile;
		this.password = password;
	}


	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
