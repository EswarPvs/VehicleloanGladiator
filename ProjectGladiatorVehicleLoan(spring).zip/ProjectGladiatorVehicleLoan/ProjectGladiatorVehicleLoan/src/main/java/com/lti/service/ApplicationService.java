package com.lti.service;

import com.lti.dto.ApplicationDto;
import com.lti.entity.Application;

public interface ApplicationService {
	void addApplicationDetail(Application ref);
	public int addApplication(ApplicationDto applicationDto);

}
