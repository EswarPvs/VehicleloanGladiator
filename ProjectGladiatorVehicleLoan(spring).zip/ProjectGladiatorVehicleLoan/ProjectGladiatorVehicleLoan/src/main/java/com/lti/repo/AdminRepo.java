package com.lti.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.entity.Admin;

@Repository
public interface AdminRepo {
	
		public List<Admin> getAllAdmins();
		public Admin getOneAdmin(int adminId);
		public void addAdmin(Admin ad);
		public void updateAdminPassword(int adminId,String newPass);
		public void deleteAdmin(int adminId);
		public Admin getOneAdminByEmail(String email);
}
