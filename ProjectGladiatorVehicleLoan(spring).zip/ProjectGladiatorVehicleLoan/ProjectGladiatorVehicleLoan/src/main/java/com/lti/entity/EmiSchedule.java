package com.lti.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;


/**
 * The persistent class for the EMI_SCHEDULE database table.
 * 
 */
@Entity
@Table(name="EMI_SCHEDULE")
@NamedQuery(name="EmiSchedule.findAll", query="SELECT e FROM EmiSchedule e")
public class EmiSchedule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOAN_ID")
	private int loanId;

//	@Temporal(TemporalType.DATE)
	@Column(name="APPLIED_DATE", columnDefinition = "DATE")
	private LocalDate appliedDate;
//trackingDetail.setVerificationDate(LocalDate.of(2020, 12, 15));    LocalDate.now();
	private int emi;

	@Column(name="EMI_SCHEDULER")
	private int emiScheduler;

	@Column(name="LOAN_SANCTIONED")
	private int loanSanctioned;

	//@Temporal(TemporalType.DATE)
	@Column(name="SANCTIONED_DATE", columnDefinition = "DATE")
	private Date sanctionedDate;

	@Column(name="TOTAL_LOAN")
	private int totalLoan;

	//bi-directional one-to-one association to LoanDetail
	@OneToOne
	@JoinColumn(name="LOAN_ID")
	private LoanDetail loanDetail;

	public EmiSchedule() {
	}

	public int getLoanId() {
		return this.loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public LocalDate getAppliedDate() {
		return this.appliedDate;
	}

	public void setAppliedDate(LocalDate appliedDate) {
		this.appliedDate = appliedDate;
	}

	public int getEmi() {
		return this.emi;
	}

	public void setEmi(int emi) {
		this.emi = emi;
	}

	public int getEmiScheduler() {
		return this.emiScheduler;
	}

	public void setEmiScheduler(int emiScheduler) {
		this.emiScheduler = emiScheduler;
	}

	public int getLoanSanctioned() {
		return this.loanSanctioned;
	}

	public void setLoanSanctioned(int loanSanctioned) {
		this.loanSanctioned = loanSanctioned;
	}

	public Date getSanctionedDate() {
		return this.sanctionedDate;
	}

	public void setSanctionedDate(Date sanctionedDate) {
		this.sanctionedDate = sanctionedDate;
	}

	public int getTotalLoan() {
		return this.totalLoan;
	}

	public void setTotalLoan(int totalLoan) {
		this.totalLoan = totalLoan;
	}
	@JsonIgnore
	public LoanDetail getLoanDetail() {
		return this.loanDetail;
	}

	public void setLoanDetail(LoanDetail loanDetail) {
		this.loanDetail = loanDetail;
	}

}