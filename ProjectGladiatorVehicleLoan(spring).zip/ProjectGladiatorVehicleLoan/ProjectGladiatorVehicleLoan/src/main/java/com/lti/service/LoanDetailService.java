package com.lti.service;

import java.util.List;
import com.lti.dto.LoanDetailDto;
import com.lti.dto.LoanStatus;
import com.lti.entity.LoanDetail;

public interface LoanDetailService {
	public List<LoanDetailDto> getLoanDetails();
	public LoanDetail updateStatus(LoanStatus loanstatus);
	public LoanDetailDto  getLoanById(int lId);
	int addnewLoan (LoanDetailDto loanDetailDto);
}
