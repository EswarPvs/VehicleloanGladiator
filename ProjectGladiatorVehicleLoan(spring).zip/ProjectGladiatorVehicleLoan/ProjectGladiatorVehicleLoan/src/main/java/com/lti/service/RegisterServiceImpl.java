package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dto.RegisterDto;
import com.lti.repo.RegisterRepo;

@Service
public class RegisterServiceImpl implements RegisterServiceRepo {

    @Autowired
    RegisterRepo registerRep;
    
    @Override
	public int addUser(RegisterDto registerDto) {
		// TODO Auto-generated method stub
		return registerRep.addRegister(registerDto);
		
	}

	@Override
	public RegisterDto getUserById(int customerId) {
		// TODO Auto-generated method stub
		return this.registerRep.getUserById(customerId);
	}

}
