package com.lti.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entity.Admin;
import com.lti.entity.CarDetail;
//import com.lti.entity.Cardetail;
import com.lti.entity.Register;
@Repository
public class CarDetailRepoImpl implements CarDetailRepo {
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	@Transactional
	public List<CarDetail> getAllCars() {
		String s = "From CarDetail";
		Query query = entityManager.createQuery(s);
		List<CarDetail> cd = query.getResultList();
		return cd;
	}

	
	@Transactional
	public CarDetail getOneCar(int vehId) {
		CarDetail cd = entityManager.find(CarDetail.class,vehId);
		return cd;
	}

	
	@Transactional
	public void addCar(CarDetail car) {
		System.out.println(entityManager);
		entityManager.merge(car);

	}

	
	@Transactional
	public void updateCar(int vehId, int newExPrice) {
		CarDetail car = entityManager.find(CarDetail.class, vehId);
		car.setExPrice(newExPrice);
		entityManager.merge(car);


	}

	/*
	@Transactional
	public void deleteCar(int vehId) {
		CarDetail cd = entityManager.find(CarDetail.class, vehId);
		entityManager.remove(cd);

	}*/

}
