package com.lti.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

//import com.lti.entity.CarDetail;
import com.lti.entity.EmiSchedule;
@Repository
public class EmiScheduleRepoImpl implements EmiSchedRepo {
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	@Transactional
	public List<EmiSchedule> getAllEmiSchedules() {
		String s = "From EmiSchedule";
		Query query = entityManager.createQuery(s);
		List<EmiSchedule> es = query.getResultList();
		return es;
	}

	
	@Transactional
	public EmiSchedule getOneEmiSched(int loanId) {
		EmiSchedule es = entityManager.find(EmiSchedule.class,loanId);
		return es;
	}

	
	@Transactional
	public void updateLoanSanctioned(int loanId, int newAmount) {
		EmiSchedule emi = entityManager.find(EmiSchedule.class, loanId);
		emi.setLoanSanctioned(newAmount);
		entityManager.merge(emi);

	}

	
	@Transactional
	public void updateEmiScheduler(int loanId, int newSchedule) {
		EmiSchedule emi = entityManager.find(EmiSchedule.class, loanId);
		emi.setEmiScheduler(newSchedule);
		entityManager.merge(emi);

	}

}
