package com.lti.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entity.Admin;

@Repository
public class AdminRepoImpl implements AdminRepo {
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	@Transactional
	public List<Admin> getAllAdmins() {
		String s = "From Admin";
		Query query = entityManager.createQuery(s);
		List<Admin> admin = query.getResultList();
		return admin;
	}

	
	@Transactional
	public Admin getOneAdmin(int adminId) {
		Admin admin = entityManager.find(Admin.class,adminId);
		return admin;
	}

	
	@Transactional
	public void addAdmin(Admin ad) {
		System.out.println(entityManager);
		entityManager.persist(ad);

	}

	
	@Transactional
	public void updateAdminPassword(int adminId, String newPass) {
		Admin ad = entityManager.find(Admin.class, adminId);
		ad.setAdminPass(newPass);//setAdpass(newPass);
		entityManager.merge(ad);

	}

	
	@Transactional
	public void deleteAdmin(int adminId) {
		Admin ad = entityManager.find(Admin.class, adminId);
		entityManager.remove(ad);
	}


	@Transactional
	public Admin getOneAdminByEmail(String email) {
		System.out.println("getOneAdmin(email) is called");
		System.out.println("--------------------------------------------");
		
	Query query =  entityManager.createQuery(" FROM Admin  WHERE admin_email= "+"'"+email+"'");
	System.out.println("query created");
	 List<Admin> adList = query.getResultList();
	 Admin adm = adList.get(0);
	 
	 System.out.println("Got the Admin");
	return adm;
	}

	}


