package com.lti.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dto.LoanDetailDto;
import com.lti.dto.LoanStatus;
import com.lti.entity.Application;
import com.lti.entity.CarDetail;
import com.lti.entity.LoanDetail;
import com.lti.entity.Register;

@Repository
public class LoanDetailRepoImpl implements LoanDetailRepo {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public List<LoanDetail> getAllLoanDetails() {
		
		//String s = "select ld From LoanDetails ld";
//	System.out.println("\tquery is "+s);
		Query query = entityManager.createQuery("from LoanDetail");
		List<LoanDetail> ldl = query.getResultList();
	System.out.println("\tlist is :"+ldl);
		//Set<LoanDetail> ldl = query.get
		return ldl;
	}
	
	/*@Transactional
	public Set<LoanDetail> getAllLoanDetails() {
		String s = "From LoanDetails";
		Query query = entityManager.createQuery(s);
		Set<LoanDetail> ldl = query.getResult
		//Set<LoanDetail> ldl = query.get
		return ldl;
	}*/

	
	@Transactional
	public LoanDetail getOneLoan(int loanId) {
		LoanDetail ldl = entityManager.find(LoanDetail.class, loanId);
		return ldl;
	}

	
	@Transactional
	public void addLoan(LoanDetail loan) {
		System.out.println(entityManager);
		entityManager.persist(loan);
	}

	
	@Transactional
	public void updateLoanStatus(int loanId,String newStatus) {
		LoanDetail ldl = entityManager.find(LoanDetail.class, loanId);
		ldl.setStatus(newStatus);
		entityManager.merge(ldl);

	}

	@Override
	public List<LoanDetailDto> getLoanDetails() {
		List<LoanDetailDto>  loanDetailDto = new ArrayList<LoanDetailDto>();
		String query = "from LoanDetail";
		LoanDetail ld=null;
		Query q = null;
		q = (Query) this.entityManager.createQuery(query);
		List<LoanDetail> loanDetail = q.getResultList();
		for(LoanDetail d : loanDetail) {
			 int loanID = d.getLoanId();
			 int vehicleID =d.getCarDetail().getVehicleId();
			 int applicationID=d.getApplication().getApplicationId();
			 int reqAmount=d.getReqAmount();
			 double roi = d.getRoi();
			 int tenure=d.getTenure();
			 String status=d.getStatus();
			 loanDetailDto.add(new LoanDetailDto(loanID,vehicleID,applicationID,reqAmount,roi,tenure,status));
		}
		return loanDetailDto;
	}
    @Transactional
	@Override
	public LoanDetail updateStatus(LoanStatus loanStatus) {
    	int lId = loanStatus.getLoanId();
		LoanDetail loanstatus = this.entityManager.find(LoanDetail.class, lId);
		loanstatus.setStatus(loanStatus.getStatus());
		this.entityManager.merge(loanstatus);
		return loanstatus;
	}
    @Transactional
	@Override
	public LoanDetailDto getLoanById(int lId) {
	
		LoanDetailDto ldt;
		LoanDetail loandetail = entityManager.find(LoanDetail.class, lId);
		
		int loanID = loandetail.getLoanId();
		 int vehicleID =loandetail.getCarDetail().getVehicleId();
		 int applicationID=loandetail.getApplication().getApplicationId();
		 int reqAmount=loandetail.getReqAmount();
		 double roi = loandetail.getRoi();
		 int tenure=loandetail.getTenure();
		 String status=loandetail.getStatus();
		ldt=new  LoanDetailDto(loanID,vehicleID,applicationID,reqAmount,roi,tenure,status);
		return ldt;
	}

    @Transactional
	public int addnewLoan(LoanDetailDto loanDetailDto) {
		CarDetail cd = this.entityManager.find(CarDetail.class,loanDetailDto.getVehicleId());
		Application app = this.entityManager.find(Application.class, loanDetailDto.getApplicationId());
		LoanDetail ld = new LoanDetail();
		ld.setReqAmount(loanDetailDto.getReqAmount());
		ld.setRoi(loanDetailDto.getRoi());
		ld.setTenure(loanDetailDto.getTenure());
		ld.setStatus(loanDetailDto.getStatus());
		ld.setCarDetail(cd);
		ld.setApplication(app);
		this.entityManager.persist(ld);
		System.out.println("Added successfully");
                Query q = null;
		
		String query = "from LoanDetail where req_amount=:x";
		q = (Query) this.entityManager.createQuery(query);
		q.setParameter("x", ld.getReqAmount());
	        LoanDetail l = (LoanDetail) q.getSingleResult();		
		
		return l.getLoanId();
	}
}
		

