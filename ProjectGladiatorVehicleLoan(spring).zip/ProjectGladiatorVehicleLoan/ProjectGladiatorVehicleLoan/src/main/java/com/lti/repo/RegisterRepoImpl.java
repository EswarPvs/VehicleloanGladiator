package com.lti.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.lti.dto.RegisterDto;
import com.lti.entity.Register;


@Repository
public class RegisterRepoImpl implements RegisterRepo {
	
	@PersistenceContext
	EntityManager entityManager;
	
	

	@Transactional
	public Register getOneRegisterer(int custId) {
		Register register = entityManager.find(Register.class, custId);
		return register;
	}

	@Transactional
	public List<Register> getAllRegisterers() {
		String s = "From Register";
		Query query = entityManager.createQuery(s);
		List<Register> register = query.getResultList();
		return register;
	}

	@Transactional
	public void addRegisterer(Register ref) {
		System.out.println(entityManager);
		entityManager.persist(ref);

	}

	

	@Transactional
	public void updateRegistererPassword(int custId, String newPassword) {
		Register register = entityManager.find(Register.class, custId);
		register.setPassword(newPassword);
		entityManager.merge(register);

	}

	@Transactional
	public int addRegister(RegisterDto registerDto) {
		Register register=new Register();
		register.setAlterMobile(registerDto.getaMobile());
		register.setDob(registerDto.getDob());
		register.setEmail(registerDto.getEmail());
		register.setFirstName(registerDto.getfName());
		register.setLastName(registerDto.getlName());
		register.setMiddleName(registerDto.getMName());
		register.setMobile(registerDto.getMobile());
		register.setPan(registerDto.getPan());
		register.setPassword(registerDto.getuPassword());
		register.setPincode(registerDto.getPincode());
		register.setState(registerDto.getState());
		register.setCity(registerDto.getCity());
		register.setGender(registerDto.getGender());
		this.entityManager.persist(register);
		System.out.println("Added successfully");
		
		       Query q = null;
				
				String query = "from Register where email=:x";
				q = (Query) this.entityManager.createQuery(query);
				q.setParameter("x", register.getEmail());
			    Register r= (Register) q.getSingleResult();
				return r.getCustomerId();
		
	}

	@Transactional
	public RegisterDto getUserById(int custid) {
		RegisterDto registerDto ;
		Register register = this.entityManager.find(Register.class, custid);
		System.out.println("User is :"+register.getFirstName());
		 String fName = register.getFirstName();
		 String email = register.getEmail();
		 String state = register.getState();
		 String mobile = register.getMobile();
		 String amobile= register.getAlterMobile();
	registerDto=new RegisterDto (fName,mobile,email,amobile,state);
		return registerDto;

	}

	@Transactional
	public Register getOneUserwithEmail(String email) {
		System.out.println("getOneUSer(email) is called");
		System.out.println("--------------------------------------------");
		
	Query query =  entityManager.createQuery(" FROM Register  WHERE email= "+"'"+email+"'");
	System.out.println("query created");
	 List<Register> regList = query.getResultList();
	 Register reg = regList.get(0);
	 
	 System.out.println("Got the user");
	return reg;
		
	}

	

}
