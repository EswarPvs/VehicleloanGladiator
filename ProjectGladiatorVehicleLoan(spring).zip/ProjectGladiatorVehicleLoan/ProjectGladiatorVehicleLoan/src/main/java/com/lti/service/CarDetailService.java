package com.lti.service;

import java.util.List;

import com.lti.entity.CarDetail;

public interface CarDetailService {
		public List<CarDetail> getAllCars();
}
