package com.lti.repo;

import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Repository;

import com.lti.dto.LoanDetailDto;
import com.lti.dto.LoanStatus;
import com.lti.entity.LoanDetail;
//import com.lti.entity.Loandetail;
@Repository
public interface LoanDetailRepo {
	public List<LoanDetail> getAllLoanDetails();
	//public Set<Loandetail> getAllLoanDetails();
	public LoanDetail getOneLoan(int loanId);
	public void addLoan(LoanDetail loan);
	public void updateLoanStatus(int loanId, String newStatus);
	public List<LoanDetailDto> getLoanDetails ();
	public LoanDetail updateStatus(	LoanStatus loanStatus);
	public LoanDetailDto  getLoanById(int lId);
	public int addnewLoan (LoanDetailDto loanDetailDto);
	
	
}
