package com.lti.service;


import com.lti.dto.RegisterDto;

public interface RegisterServiceRepo {
	public int addUser(RegisterDto registerDto);
	public RegisterDto getUserById(int customerId);

}
