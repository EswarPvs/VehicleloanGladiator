package com.lti.service;


import com.lti.dto.AdminLoginDto;
import com.lti.dto.AdminSignUP;
import com.lti.dto.LoginStatus;
import com.lti.dto.UserLoginDto;
import com.lti.exception.VehicleLoanException;



public interface LoginService {

	public LoginStatus userLogin(UserLoginDto ulDto) throws VehicleLoanException;
	public AdminSignUP adminLogin(AdminLoginDto alDto) throws VehicleLoanException;
	
}
