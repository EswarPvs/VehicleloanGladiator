package com.lti.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the "IDENTITY" database table.
 * 
 */
@Entity
@Table(name="IDENTITY")
@NamedQuery(name="Identity.findAll", query="SELECT i FROM Identity i")
public class Identity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="APPLICATION_ID")
	private long applicationId;

	@Column(name="ACCOUNT_STAT")
	private String accountStat;

	@Column(name="ADHAAR_DOC")
	private String adhaarDoc;

	@Column(name="PAN_DOC")
	private String panDoc;

	@Column(name="SALARY_SLIP")
	private String salarySlip;

	//bi-directional one-to-one association to Application
	@OneToOne
	@JoinColumn(name="APPLICATION_ID")
	private Application application;

	public Identity() {
	}

	public long getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public String getAccountStat() {
		return this.accountStat;
	}

	public void setAccountStat(String accountStat) {
		this.accountStat = accountStat;
	}

	public String getAdhaarDoc() {
		return this.adhaarDoc;
	}

	public void setAdhaarDoc(String adhaarDoc) {
		this.adhaarDoc = adhaarDoc;
	}

	public String getPanDoc() {
		return this.panDoc;
	}

	public void setPanDoc(String panDoc) {
		this.panDoc = panDoc;
	}

	public String getSalarySlip() {
		return this.salarySlip;
	}

	public void setSalarySlip(String salarySlip) {
		this.salarySlip = salarySlip;
	}
	
	@JsonIgnore
	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}