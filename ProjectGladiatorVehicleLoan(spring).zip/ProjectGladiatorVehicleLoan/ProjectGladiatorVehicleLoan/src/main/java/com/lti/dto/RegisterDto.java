package com.lti.dto;
import java.time.LocalDate;


public class RegisterDto {
	private String fName;
	private String lName;
	private String mName;
	private String mobile;
	private String email;
	private String uPassword;
	private String aMobile;
	private LocalDate dob;
	private String pan;
	private int pincode;
	private String state;
	private String gender;
	private String city;

	
	public RegisterDto() {

	}
	
	public RegisterDto(String fName, String lName, String mName, String mobile, String email, String uPassword,
			String aMobile, LocalDate dob, String pan, int pincode, String state, String gender,String city ) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.mName = mName;
		this.mobile = mobile;
		this.email = email;
		this.uPassword = uPassword;
		this.aMobile = aMobile;
		this.dob = dob;
		this.pan = pan;
		this.pincode = pincode;
		this.state = state;
		this.city=city;
		this.gender=gender;
	}
	

	public RegisterDto(String fName, String mobile, String email, String aMobile, String state) {
		super();
		this.fName = fName;
		this.mobile = mobile;
		this.email = email;
		this.aMobile = aMobile;
		this.state = state;
	}

	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getMName() {
		return mName;
	}
	public void setMName(String mName) {
		this.mName = mName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getuPassword() {
		return uPassword;
	}
	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}
	public String getaMobile() {
		return aMobile;
	}
	public void setaMobile(String aMobile) {
		this.aMobile = aMobile;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
}
