package com.lti.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the LOAN_DETAILS database table.
 * 
 */
@Entity
@Table(name="LOAN_DETAILS")
@NamedQuery(name="LoanDetail.findAll", query="SELECT l FROM LoanDetail l")
public class LoanDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOAN_ID")
	private int loanId;

	@Column(name="REQ_AMOUNT")
	private int reqAmount;

	private double roi;

	private String status;

	private int tenure;

	//bi-directional one-to-one association to EmiSchedule
	@OneToOne(mappedBy="loanDetail")
	private EmiSchedule emiSchedule;
	/*
	//bi-directional many-to-one association to Application
	@ManyToOne
	@JoinColumn(name="APPLICATION_ID")
	private Application application1;
	*/
	//bi-directional many-to-one association to CarDetail
	@ManyToOne
	@JoinColumn(name="VEHICLE_ID")
	private CarDetail carDetail;

	//bi-directional one-to-one association to Application
	@OneToOne//(mappedBy="loanDetail")
	@JoinColumn(name="APPLICATION_ID", unique = true )
	private Application application;

	public LoanDetail() {
	}

	public int getLoanId() {
		return this.loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public int getReqAmount() {
		return this.reqAmount;
	}

	public void setReqAmount(int reqAmount) {
		this.reqAmount = reqAmount;
	}

	public double getRoi() {
		return this.roi;
	}

	public void setRoi(double roi) {
		this.roi = roi;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTenure() {
		return this.tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public EmiSchedule getEmiSchedule() {
		return this.emiSchedule;
	}

	public void setEmiSchedule(EmiSchedule emiSchedule) {
		this.emiSchedule = emiSchedule;
	}
	/*
	public Application getApplication1() {
		return this.application1;
	}

	public void setApplication1(Application application1) {
		this.application1 = application1;
	}
	*/
	@JsonIgnore
	public CarDetail getCarDetail() {
		return this.carDetail;
	}

	public void setCarDetail(CarDetail carDetail) {
		this.carDetail = carDetail;
	}
	@JsonIgnore
	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}