package com.lti.dto;

public class ApplicationDto {
	
	private int applicationId;
	private int customerId;
	private String aadhaar;
	private String address;
	private int accountNo;
	private String accountType;
	private String branch;
	private String ifsc;
	private int annualIncome;
	private int existingEmi;	
	private String licence;
	private String occupation;
	
	
	
	public ApplicationDto() {
		
	}
	
	public ApplicationDto(int applicationId,int customerId, String aadhaar, String address, int accountNo, String accountType,
			String branch, String ifsc, int annualIncome, int existingEmi, String licence, String occupation
			) {
		super();
		this.applicationId = applicationId;
		this.customerId = customerId;
		this.aadhaar = aadhaar;
		this.address = address;
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.branch = branch;
		this.ifsc = ifsc;
		this.annualIncome = annualIncome;
		this.existingEmi = existingEmi;
		this.licence = licence;
		this.occupation = occupation;
		
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getAadhaar() {
		return aadhaar;
	}

	public void setAadhaar(String aadhaar) {
		this.aadhaar = aadhaar;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public int getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(int annualIncome) {
		this.annualIncome = annualIncome;
	}

	public int getExistingEmi() {
		return existingEmi;
	}

	public void setExistingEmi(int existingEmi) {
		this.existingEmi = existingEmi;
	}

	public String getLicence() {
		return licence;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	
}



