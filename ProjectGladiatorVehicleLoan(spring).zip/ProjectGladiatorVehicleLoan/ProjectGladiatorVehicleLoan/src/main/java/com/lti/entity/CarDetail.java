package com.lti.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;


/**
 * The persistent class for the CAR_DETAILS database table.
 * 
 */
@Entity
@Table(name="CAR_DETAILS")
@NamedQuery(name="CarDetail.findAll", query="SELECT c FROM CarDetail c")
public class CarDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="VEHICLE_ID")
	private int vehicleId;

	private String category;

	private String color;

	@Column(name="COMPANY_NAME")
	private String companyName;

	@Column(name="EX_PRICE")
	private int exPrice;

	private String model;

	private String variant;

	//bi-directional many-to-one association to LoanDetail
	@OneToMany(mappedBy="carDetail", fetch=FetchType.EAGER)
	private Set<LoanDetail> loanDetails;

	public CarDetail() {
	}

	public int getVehicleId() {
		return this.vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getColor() {
		return this.color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCompanyName() {
		return this.companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getExPrice() {
		return this.exPrice;
	}

	public void setExPrice(int exPrice) {
		this.exPrice = exPrice;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getVariant() {
		return this.variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}
	 
	@JsonIgnore
	public Set<LoanDetail> getLoanDetails() {
		return this.loanDetails;
	}

	public void setLoanDetails(Set<LoanDetail> loanDetails) {
		this.loanDetails = loanDetails;
	}

	public LoanDetail addLoanDetail(LoanDetail loanDetail) {
		getLoanDetails().add(loanDetail);
		loanDetail.setCarDetail(this);

		return loanDetail;
	}

	public LoanDetail removeLoanDetail(LoanDetail loanDetail) {
		getLoanDetails().remove(loanDetail);
		loanDetail.setCarDetail(null);

		return loanDetail;
	}

}