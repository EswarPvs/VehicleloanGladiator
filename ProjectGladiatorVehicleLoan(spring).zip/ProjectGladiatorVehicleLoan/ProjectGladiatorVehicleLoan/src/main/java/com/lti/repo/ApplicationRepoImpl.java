package com.lti.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dto.ApplicationDto;
import com.lti.entity.Application;
import com.lti.entity.Register;

@Repository
public class ApplicationRepoImpl implements ApplicationRepo {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public Application getOneApplication(int appId) {
		Application application = entityManager.find(Application.class, appId);
		return application;
	}

	@Transactional
	public List<Application> getAllApplications() {
		String s = "From Application";
		Query query = entityManager.createQuery(s);
		List<Application> application = query.getResultList();
		return application;
	}

	@Transactional
	public void addApplication(Application ref) {
		System.out.println(entityManager);
		entityManager.merge(ref);

	}
	@Transactional
	 public List<Object[]>getApplicantdetails()
	 {
	   Query query=entityManager.createNativeQuery("select r.email,a.aadhaar,c.company_name,ld.loan_id,ld.req_amount from register r,application a,car_details c,loan_details ld where r.customer_id=a.customer_id and a.application_id=ld.application_id and c.vehicle_id=ld.vehicle_id");
	   List<Object[]> applicants=query.getResultList();
	   return applicants;
	 }
    @Transactional
	@Override
	public int addApplication(ApplicationDto applicationDto) {
		Register r = this.entityManager.find(Register.class, applicationDto.getCustomerId());
		Application app = new Application();
		app.setAadhaar(applicationDto.getAadhaar());
		app.setAccountNo(applicationDto.getAccountNo());
		app.setAccountType(applicationDto.getAccountType());
		app.setAddress(applicationDto.getAddress());
		app.setAnnualIncome(applicationDto.getAnnualIncome());
		app.setBranch(applicationDto.getBranch());
		app.setExistingEmi(applicationDto.getExistingEmi());
		app.setIfsc(applicationDto.getIfsc());
		app.setLicence(applicationDto.getLicence());
		app.setOccupation(applicationDto.getOccupation());
		app.setRegister(r);
		this.entityManager.persist(app);
		System.out.println("Added successfully");
Query q = null;
		
		String query = "from Application where aadhaar=:x";
		q = (Query) this.entityManager.createQuery(query);
		q.setParameter("x", app.getAadhaar());
	Application a = (Application) q.getSingleResult();		
		
		return a.getApplicationId();
	}
		

	
	

}
